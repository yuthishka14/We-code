package com.example.ecommerce1;public class VeiwGroup {
}
